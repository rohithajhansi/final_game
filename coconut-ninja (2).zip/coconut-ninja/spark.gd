extends Node2D
# little star pop when you cut a coconut (3 frames)

var t = 0.0
var sheet = load("res://assets/spark_sheet.png")

func _process(delta):
	t += delta
	if t >= 0.36:
		queue_free()
	queue_redraw()

func _draw():
	var f = clamp(int(t / 0.12), 0, 2)
	draw_texture_rect_region(sheet, Rect2(-16, -16, 32, 32), Rect2(f * 32, 0, 32, 32))
