extends Node2D
# main game script: spawns coconuts, checks hits, keeps score, draws the world

var NinjaScript = preload("res://ninja.gd")
var CoconutScript = preload("res://coconut.gd")
var HalfScript = preload("res://half.gd")
var SparkScript = preload("res://spark.gd")

var bg_tex = load("res://assets/bg.png")
var palm_sheet = load("res://assets/palm_sheet.png")
var tramp_tex = load("res://assets/trampoline.png")
var cloud_tex = load("res://assets/cloud.png")
var waves_tex = load("res://assets/waves.png")

var trees = [120, 360, 600, 840]
var palm_order = [0, 1, 2, 3, 2, 1]   # sway back and forth
var cloud_start = [100.0, 420.0, 760.0]
var cloud_speed = [12.0, 8.0, 15.0]
var cloud_y = [40, 95, 25]

var ninja
var coconuts = []
var dips = []          # trampoline dents
var anim_time = 0.0
var spawn_timer = 1.0
var time_alive = 0.0
var cuts = 0
var dead = false
var score_label
var over_label

func _ready():
	# background music (loops forever)
	var music = AudioStreamPlayer.new()
	music.stream = load("res://music.wav")
	music.volume_db = -8
	add_child(music)
	music.play()
	music.finished.connect(music.play)

	ninja = NinjaScript.new()
	ninja.position = Vector2(480, 460)
	ninja.landed.connect(_on_land)
	add_child(ninja)

	score_label = Label.new()
	score_label.position = Vector2(20, 15)
	score_label.add_theme_font_size_override("font_size", 24)
	add_child(score_label)

	over_label = Label.new()
	over_label.position = Vector2(300, 220)
	over_label.add_theme_font_size_override("font_size", 40)
	over_label.text = "You got coconutted!\nPress R to bounce back"
	over_label.visible = false
	add_child(over_label)

func _on_land(x, power):
	# dent the trampoline where something landed
	dips.append({"x": x, "power": power, "age": 0.0})
	if dips.size() > 12:
		dips.pop_front()

func _input(event):
	if dead:
		return
	if event.is_action_pressed("ui_accept") or (event is InputEventMouseButton and event.pressed):
		ninja.slash()
		# cut any coconut close to the ninja
		for c in coconuts.duplicate():
			if c.position.distance_to(ninja.position) < 90:
				# two halves fly apart + a spark
				for side in [-1, 1]:
					var h = HalfScript.new()
					h.position = c.position
					h.vel = Vector2(side * 130, -160)
					h.flip = side
					add_child(h)
				var sp = SparkScript.new()
				sp.position = c.position
				add_child(sp)
				coconuts.erase(c)
				c.queue_free()
				cuts += 1

func _process(delta):
	anim_time += delta
	for d in dips.duplicate():
		d.age += delta
		if d.age > 0.7:
			dips.erase(d)
	queue_redraw()

	if dead:
		if Input.is_key_pressed(KEY_R):
			get_tree().reload_current_scene()
		return

	time_alive += delta

	# drop a new coconut every so often (gets faster)
	spawn_timer -= delta
	if spawn_timer <= 0:
		var c = CoconutScript.new()
		c.position = Vector2(trees[randi() % 4] + randf_range(-40, 40), 156)
		c.landed.connect(_on_land)
		add_child(c)
		coconuts.append(c)
		spawn_timer = max(0.5, 1.5 - time_alive * 0.02)

	for c in coconuts.duplicate():
		if c.age > 12:
			coconuts.erase(c)
			c.queue_free()
		elif c.hang_time <= 0 and c.position.distance_to(ninja.position) < 30:
			dead = true
			ninja.die()
			over_label.visible = true

	score_label.text = "Time: " + str(int(time_alive)) + "   Cut: " + str(cuts)

func _draw():
	draw_texture(bg_tex, Vector2(0, 0))

	# clouds drift to the right
	for i in 3:
		var cx = fmod(cloud_start[i] + anim_time * cloud_speed[i], 1100.0) - 140.0
		draw_texture(cloud_tex, Vector2(cx, cloud_y[i]))

	# two layers of waves moving opposite ways
	draw_texture(waves_tex, Vector2(-60 + sin(anim_time * 0.9) * 40, 400))
	draw_texture(waves_tex, Vector2(-60 - sin(anim_time * 0.9 + 2) * 40, 412), Color(1, 1, 1, 0.6))

	# palm trees sway (each one a little out of sync)
	for i in trees.size():
		var frame = palm_order[int(anim_time * 5 + i * 2) % 6]
		draw_texture_rect_region(palm_sheet, Rect2(trees[i] - 80, 100, 160, 400), Rect2(frame * 160, 0, 160, 400))

	# trampoline, drawn in strips so it can dent
	for i in 48:
		var x = i * 20
		var dy = 0.0
		for d in dips:
			var falloff = max(0.0, 1.0 - abs(x + 10 - d.x) / 160.0)
			dy += 14.0 * d.power * exp(-d.age * 7.0) * cos(d.age * 22.0) * falloff
		dy = clamp(snappedf(dy, 2.0), -6.0, 18.0)
		draw_texture_rect_region(tramp_tex, Rect2(x, 480 + dy, 20, 20), Rect2(x, 0, 20, 20))
