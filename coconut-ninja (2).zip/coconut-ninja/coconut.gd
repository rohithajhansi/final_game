extends Node2D
# a coconut. hangs and shakes in the tree first (warning!), then falls and bounces

signal landed(x, power)

var vel = Vector2.ZERO
var age = 0.0
var hang_time = 0.7
var squash_time = 0.0
var rot = 0.0
var tex = load("res://assets/coconut.png")

func _ready():
	vel.x = randf_range(-60, 60)

func _process(delta):
	if hang_time > 0:
		hang_time -= delta
		queue_redraw()
		return

	vel.y += 700 * delta
	position += vel * delta
	age += delta
	rot += vel.x * 0.01 * delta

	# bounce off the trampoline
	if position.y >= 466:
		position.y = 466
		vel.y = -max(abs(vel.y) * 0.9, 450)
		squash_time = 0.12
		landed.emit(position.x, 0.5)
	if squash_time > 0:
		squash_time -= delta
	queue_redraw()

func _draw():
	if hang_time > 0:
		# shake while hanging
		var shake = sin(Time.get_ticks_msec() * 0.06) * 2.5
		draw_set_transform(Vector2(shake, 0), 0, Vector2.ONE)
	else:
		# squash when it hits the trampoline
		var k = clamp(squash_time / 0.12, 0, 1)
		var sx = 1.0 + 0.3 * k
		var sy = 1.0 - 0.3 * k
		draw_set_transform(Vector2(0, 16 * (1 - sy)), rot, Vector2(sx, sy))
	draw_texture(tex, Vector2(-16, -16))
