# Coconut Ninja
Hackathon game. Theme: Bounce Back.
A ninja bounces on a trampoline island. Coconuts fall. Slice them or die.

Controls: Left/Right arrows = move, Space or mouse click = slash, R = restart
Engine: Godot 4.3 or newer

---

## HOW TO RUN IT (read this first)

### Step 1: Get Godot
1. Go to godotengine.org and click Download.
2. Download the normal version (NOT the ".NET" / "Mono" one).
3. You get a zip. Extract it. Inside is the Godot app. You do NOT need to install it, just double-click it.
4. Check the version is 4.3 or higher.

### Step 2: Unzip the game
1. Right-click coconut-ninja.zip -> Extract All (Windows) or double-click it (Mac).
2. Open the extracted folder. Make sure you can see these files: project.godot, main.gd, ninja.gd, coconut.gd, music.wav.
   If you only see ANOTHER folder, open that one.
   Do not skip this. Godot cannot open a project from inside a zip.

### Step 3: Open it in Godot
Pick ONE of these:
- A) Open Godot -> click Import -> click Browse -> go into the folder from Step 2 -> click the file project.godot -> click Open -> click Import & Edit.
- B) Drag the project.godot file and drop it onto the Godot window.
- C) Right-click project.godot -> Open with -> Godot.

Wait about 10 seconds the first time. Godot is importing the music.

### Step 4: Play
Press F5 (or the Play button, top right). If a window asks to select a main scene, pick main.tscn.

### If it doesn't work
- Import & Edit is greyed out: you picked the folder or the zip. Pick the file project.godot.
- "Failed to load project" / version error: your Godot is too old. Get 4.3+.
- No sound: check your volume, then close and reopen the project so the music imports.
- Game is a blank gray window: press F5 again after the import finishes.

---

## HOW TO USE GITHUB WITH YOUR TEAM

Easiest way: GitHub Desktop (desktop.github.com). No commands needed.

### Person 1 (makes the repo)
1. Make a free account at github.com.
2. Click New repository. Name it coconut-ninja. Click Create.
3. Click "uploading an existing file". Drag in everything from the extracted game folder. Click Commit changes.
4. Go to Settings -> Collaborators -> Add people. Add your 2 teammates by username.

### Persons 2 and 3 (join)
1. Accept the invite email from GitHub.
2. Open GitHub Desktop -> File -> Clone repository -> pick coconut-ninja -> Clone.
3. Open the cloned folder in Godot (Step 3 above).

### Every time you work
1. Open GitHub Desktop and click Fetch / Pull origin (gets your teammates' changes).
2. Work on YOUR file only.
3. Write a short message, click Commit, then Push origin.

### Who edits what (so you never fight over a file)
- main.gd: person 1 (spawning, score, difficulty, title screen)
- ninja.gd: person 2 (movement, slash, ninja art)
- coconut.gd: person 3 (coconut behavior, trees and trampoline art)
If you need to edit someone else's file, tell them first.

---

## MUSIC
music.wav is a placeholder loop made for this project. To use your own song:
1. Put the file in the game folder (.wav or .ogg).
2. In main.gd, change "res://music.wav" to your file name.
Only use music you have the rights to (free sources: pixabay.com/music, incompetech.com).

---

## ART + ANIMATION (assets folder)
Animated things use a sprite sheet = frames side by side in one picture. Code picks the frame.
- ninja_sheet.png (256x64): 4 frames 64x64. normal, stretch (going up), squash (landing), dead
- palm_sheet.png (640x400): 4 frames 160x400. fronds sway
- slash_sheet.png (576x192): 3 frames 192x192. sword swoosh
- spark_sheet.png (96x32): 3 frames 32x32. star pop when you cut a coconut
Single pictures: bg.png (960x540), trampoline.png (960x20), coconut.png (32x32), coconut_half.png (32x16), cloud.png (160x64), waves.png (1080x80)

What moves by code (no extra art): clouds drift, waves slide, coconut shakes before it drops, coconut squashes when it bounces, trampoline dents where things land, halves spin when sliced, ninja spins off screen when he dies.

To use your own art: same file name, same size, same number of frames. Free pixel art editor: piskelapp.com
