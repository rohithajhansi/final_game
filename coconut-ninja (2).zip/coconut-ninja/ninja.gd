extends Node2D
# the ninja. keeps bouncing, you steer him left/right
# animation frames (ninja_sheet.png): 0 normal, 1 stretch (going up), 2 squash (landing), 3 dead

signal landed(x, power)

const GRAVITY = 1400
const BOUNCE = -750
const SPEED = 300
const GROUND = 460

var vel_y = 0.0
var facing = 1
var slash_time = 0.0
var squash_time = 0.0
var dead = false
var sheet = load("res://assets/ninja_sheet.png")
var slash_sheet = load("res://assets/slash_sheet.png")

func _process(delta):
	if dead:
		# fall off the screen spinning
		vel_y += GRAVITY * delta
		position.y += vel_y * delta
		rotation += 8 * delta * facing
		queue_redraw()
		return

	var dir = Input.get_axis("ui_left", "ui_right")
	if dir > 0:
		facing = 1
	elif dir < 0:
		facing = -1
	position.x += dir * SPEED * delta
	position.x = clamp(position.x, 20, 940)

	# gravity + bounce
	vel_y += GRAVITY * delta
	position.y += vel_y * delta
	if position.y >= GROUND:
		position.y = GROUND
		vel_y = BOUNCE
		squash_time = 0.12
		landed.emit(position.x, 1.0)

	if squash_time > 0:
		squash_time -= delta
	if slash_time > 0:
		slash_time -= delta
	queue_redraw()

func slash():
	slash_time = 0.2

func die():
	dead = true
	vel_y = -450

func _draw():
	var frame = 0
	if dead:
		frame = 3
	elif squash_time > 0:
		frame = 2
	elif vel_y < -250:
		frame = 1

	# facing = -1 flips the picture
	draw_set_transform(Vector2.ZERO, 0, Vector2(facing, 1))
	draw_texture_rect_region(sheet, Rect2(-32, -32, 64, 64), Rect2(frame * 64, 0, 64, 64))

	if slash_time > 0 and not dead:
		var f = clamp(int((1.0 - slash_time / 0.2) * 3), 0, 2)
		draw_texture_rect_region(slash_sheet, Rect2(-96, -96, 192, 192), Rect2(f * 192, 0, 192, 192))
