extends Node2D
# one half of a sliced coconut. flies off, spins and fades

var vel = Vector2.ZERO
var life = 1.0
var flip = 1
var tex = load("res://assets/coconut_half.png")

func _process(delta):
	vel.y += 900 * delta
	position += vel * delta
	rotation += flip * 7 * delta
	life -= delta
	modulate.a = life
	if life <= 0:
		queue_free()
	queue_redraw()

func _draw():
	draw_set_transform(Vector2.ZERO, 0, Vector2(flip, 1))
	draw_texture(tex, Vector2(-16, -8))
